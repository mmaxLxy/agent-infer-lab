#include <cstdint>
#include <tuple>

#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAException.h>
#include <c10/cuda/CUDAGuard.h>
#include <cuda.h>
#include <cuda_runtime.h>
#include <torch/extension.h>

namespace {

__global__ void resolve_slots_kernel(
    const std::int64_t* slots,
    std::int64_t* locations,
    std::int64_t num_slots,
    std::int64_t block_size
) {
    const std::int64_t index =
        static_cast<std::int64_t>(blockIdx.x)
            * blockDim.x
        + threadIdx.x;

    if (index >= num_slots) {
        return;
    }

    const std::int64_t slot = slots[index];

    locations[index * 2] =
        slot / block_size;
    locations[index * 2 + 1] =
        slot % block_size;
}

__global__ void append_kv_cache_v1_kernel(
    const at::Half* keys,
    const at::Half* values,
    at::Half* key_cache,
    at::Half* value_cache,
    const std::int64_t* slot_mapping,
    std::int64_t num_elements,
    std::int64_t values_per_token
) {
    const std::int64_t element_index =
        static_cast<std::int64_t>(blockIdx.x)
            * blockDim.x
        + threadIdx.x;

    if (element_index >= num_elements) {
        return;
    }

    const std::int64_t token_index =
        element_index / values_per_token;
    const std::int64_t value_offset =
        element_index % values_per_token;
    const std::int64_t slot =
        slot_mapping[token_index];

    const std::int64_t cache_index =
        slot * values_per_token
        + value_offset;

    key_cache[cache_index] =
        keys[element_index];
    value_cache[cache_index] =
        values[element_index];
}

__global__ void gather_kv_cache_v1_kernel(
    const at::Half* key_cache,
    const at::Half* value_cache,
    at::Half* gathered_keys,
    at::Half* gathered_values,
    const std::int64_t* slot_mapping,
    std::int64_t num_elements,
    std::int64_t values_per_token
) {
    const std::int64_t element_index =
        static_cast<std::int64_t>(blockIdx.x)
            * blockDim.x
        + threadIdx.x;

    if (element_index >= num_elements) {
        return;
    }

    const std::int64_t token_index =
        element_index / values_per_token;
    const std::int64_t value_offset =
        element_index % values_per_token;
    const std::int64_t slot =
        slot_mapping[token_index];

    const std::int64_t cache_index =
        slot * values_per_token
        + value_offset;

    gathered_keys[element_index] =
        key_cache[cache_index];
    gathered_values[element_index] =
        value_cache[cache_index];
}

}  // namespace

torch::Tensor resolve_slots_cuda(
    torch::Tensor slots,
    std::int64_t block_size
) {
    const c10::cuda::CUDAGuard device_guard(
        slots.device()
    );

    torch::Tensor locations = torch::empty(
        {slots.size(0), 2},
        slots.options()
    );

    const std::int64_t num_slots =
        slots.numel();

    if (num_slots == 0) {
        return locations;
    }

    constexpr int threads_per_block = 256;

    const int num_thread_blocks =
        static_cast<int>(
            (
                num_slots
                + threads_per_block
                - 1
            )
            / threads_per_block
        );

    const cudaStream_t stream =
        at::cuda::getCurrentCUDAStream(
            slots.get_device()
        ).stream();

    resolve_slots_kernel<<<
        num_thread_blocks,
        threads_per_block,
        0,
        stream
    >>>(
        slots.data_ptr<std::int64_t>(),
        locations.data_ptr<std::int64_t>(),
        num_slots,
        block_size
    );

    C10_CUDA_KERNEL_LAUNCH_CHECK();

    return locations;
}

void append_kv_cache_v1_cuda(
    torch::Tensor keys,
    torch::Tensor values,
    torch::Tensor key_cache,
    torch::Tensor value_cache,
    torch::Tensor slot_mapping
) {
    const c10::cuda::CUDAGuard device_guard(
        keys.device()
    );

    const std::int64_t num_elements =
        keys.numel();

    if (num_elements == 0) {
        return;
    }

    const std::int64_t values_per_token =
        keys.size(1)
        * keys.size(2);

    constexpr int threads_per_block = 256;

    const int num_thread_blocks =
        static_cast<int>(
            (
                num_elements
                + threads_per_block
                - 1
            )
            / threads_per_block
        );

    const cudaStream_t stream =
        at::cuda::getCurrentCUDAStream(
            keys.get_device()
        ).stream();

    append_kv_cache_v1_kernel<<<
        num_thread_blocks,
        threads_per_block,
        0,
        stream
    >>>(
        keys.data_ptr<at::Half>(),
        values.data_ptr<at::Half>(),
        key_cache.data_ptr<at::Half>(),
        value_cache.data_ptr<at::Half>(),
        slot_mapping.data_ptr<std::int64_t>(),
        num_elements,
        values_per_token
    );

    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

void gather_kv_cache_v1_out_cuda(
    torch::Tensor key_cache,
    torch::Tensor value_cache,
    torch::Tensor slot_mapping,
    torch::Tensor gathered_keys,
    torch::Tensor gathered_values
) {
    const c10::cuda::CUDAGuard device_guard(
        key_cache.device()
    );

    const std::int64_t num_elements =
        gathered_keys.numel();

    if (num_elements == 0) {
        return;
    }

    const std::int64_t values_per_token =
        key_cache.size(2)
        * key_cache.size(3);

    constexpr int threads_per_block = 256;

    const int num_thread_blocks =
        static_cast<int>(
            (
                num_elements
                + threads_per_block
                - 1
            )
            / threads_per_block
        );

    const cudaStream_t stream =
        at::cuda::getCurrentCUDAStream(
            key_cache.get_device()
        ).stream();

    gather_kv_cache_v1_kernel<<<
        num_thread_blocks,
        threads_per_block,
        0,
        stream
    >>>(
        key_cache.data_ptr<at::Half>(),
        value_cache.data_ptr<at::Half>(),
        gathered_keys.data_ptr<at::Half>(),
        gathered_values.data_ptr<at::Half>(),
        slot_mapping.data_ptr<std::int64_t>(),
        num_elements,
        values_per_token
    );

    C10_CUDA_KERNEL_LAUNCH_CHECK();
}

std::tuple<torch::Tensor, torch::Tensor>
gather_kv_cache_v1_cuda(
    torch::Tensor key_cache,
    torch::Tensor value_cache,
    torch::Tensor slot_mapping
) {
    torch::Tensor gathered_keys =
        torch::empty(
            {
                slot_mapping.size(0),
                key_cache.size(2),
                key_cache.size(3),
            },
            key_cache.options()
        );

    torch::Tensor gathered_values =
        torch::empty(
            {
                slot_mapping.size(0),
                value_cache.size(2),
                value_cache.size(3),
            },
            value_cache.options()
        );

    gather_kv_cache_v1_out_cuda(
        key_cache,
        value_cache,
        slot_mapping,
        gathered_keys,
        gathered_values
    );

    return std::make_tuple(
        gathered_keys,
        gathered_values
    );
}
